'use clinet'

import InteractiveAvatar from '../../components/InteractiveAvatar'

export default function agent() {
  return (
    // <div className='flex flex-col my-[159px] mx-[365px] w-full'>
    <div className='flex flex-col justify-center items-center  w-full'>
      <InteractiveAvatar />
    </div>
  )
}
